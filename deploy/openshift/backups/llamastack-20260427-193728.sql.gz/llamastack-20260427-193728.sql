--
-- PostgreSQL database dump
--

\restrict gfBvpGicoDz4ct7w4Byew3QCGCfBR20gHoJqancqlDBibSsgSX8QE4QtBib5MN0

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg12+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict gfBvpGicoDz4ct7w4Byew3QCGCfBR20gHoJqancqlDBibSsgSX8QE4QtBib5MN0

